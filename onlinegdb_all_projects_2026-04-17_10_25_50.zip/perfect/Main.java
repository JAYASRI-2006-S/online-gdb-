/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Cod
*******************************************************************************/
import java.util.*;
class Main
{
	static int div(int n)
	{
	    int i, s=0;
	    for(i=1;i<n;i++)
	    {
	        if(n% i==0)
	        {
	            s+=i;
	        }
	}
	return s;
}
public static void main(String[] args)
{
    Scanner sc=new Scanner(System.in);
    int m=sc.nextInt();
    if(div(m)==m)
    {
        System.out.print("perfect");
    }
    else
    {
        System.out.print("not");
    }
}
}

