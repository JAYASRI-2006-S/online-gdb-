/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt(),i,j;
	    for(i=1;i<=n;i++){
	        for(j=i;j<n;j++){
	            System.out.print("  ");
	        }
	        for(j=1;j<=(i*2)-1;j++){
	            System.out.print("* ");
	        }
	         System.out.println();
	    }
	}
}