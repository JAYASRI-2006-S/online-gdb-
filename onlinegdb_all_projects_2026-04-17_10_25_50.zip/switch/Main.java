import java.util.*;
public class Main
{
    public static void main(String[] args) {
        int a=10,b=15;
        if(a && b)
         System.out.println();
        
      
    
}}

	    