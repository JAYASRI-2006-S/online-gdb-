/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   int num = sc.nextInt();
	   System.out.println("Enter the number");
	   int original = num,rev=0;
	   while(num>0)
	   {
	       rev=rev*10+num%10;
	       num=num / 10;
	   }
	       if(original == rev)
	       System.out.println("palindrome");
	       else
	       System.out.println("not palindrome");
	}
}

	       
	       
	  
	   
	   
	 