/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt(),lo=0,an=0;
	    while(a!=0){
	        int y=a%10;
	        a=a/10;
	        if(y==1||y==3||y==6||y==8)
	        lo+=y;
	        else
	        an+=y;
	    }
	    System.out.print(lo>an?lo-an:an-lo);
	}
}